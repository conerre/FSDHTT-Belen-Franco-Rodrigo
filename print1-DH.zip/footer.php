
<footer>
          <div class="container">
            <div class="row">
               <div class="p-4 col-md-3">
                  <h4 class="mb-4 text-white">ASIENTA</h4>
                  <p class="text-white">Siempre estamos para vos</p>
               </div>
               <div class="p-4 col-md-3">
                  <h4 class="mb-4 text-white">Sitio</h4>
                  <ul class="list-unstyled">
                     <a href="#" class="text-white"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a>
                     <br>
                     <a href="#" class="text-white">Nosotros</a>
                     <br>
                     <a href="#" class="text-white">Nuestros Servicios</a>
                     <br>
                     <a href="#" class="text-white">Historias</a>
                     <br>
                     <a href="preguntas-frecuentes.php" class="text-white">Preguntas fecuentes</a>
                  </ul>
               </div>
               <div class="p-4 col-md-3">
                  <h4 class="mb-4">Contacto</h4>
                  <p>
                     <a href="tel:+246 - 542 550 5462" class="text-white"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+549xxxxxxxxxx</a>
                  </p>
                  <p>
                     <a href="mailto:info@pingendo.com" class="text-white"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>info@asienta.com</a>
                  </p>
                  <p>
                     <a href="https://goo.gl/maps/AUq7b9W7yYJ2" class="text-white" target="blank"><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Alguna direccion</a>
                  </p>
               </div>
               <div class="p-4 col-md-3">
                  <h4 class="mb-4 text-light">Suscribite</h4>
                  <form>
                     <fieldset class="form-group text-white"> <label for="exampleInputEmail1">A nuestro newsletter</label>
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"> 
                     </fieldset>
                     <button type="submit" class="btn btn-outline-light">Enviar</button>
                  </form>
               </div>
            </div>
          </div>
      </footer>
      